/// <reference path="../dom.d.ts" />

declare global {
  const __DEV__: boolean;
  const __SERVER__: boolean;
  const __TEST__: boolean;
}

export {};
