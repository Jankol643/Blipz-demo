import { chaiDomDiff } from '@open-wc/semantic-dom-diff';

chai.use(chaiDomDiff);
