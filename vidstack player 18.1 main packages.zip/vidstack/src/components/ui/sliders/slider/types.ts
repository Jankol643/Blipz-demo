export type SliderOrientation = 'horizontal' | 'vertical';
