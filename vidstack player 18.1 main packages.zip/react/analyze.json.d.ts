import type { ReactComponentMeta } from '@maverick-js/cli/analyze';

declare const json: {
  react: ReactComponentMeta[];
};

export default json;
