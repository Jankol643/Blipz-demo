export const IS_SERVER = typeof document === 'undefined';
