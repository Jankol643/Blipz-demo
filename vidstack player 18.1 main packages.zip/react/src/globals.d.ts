declare global {
  const __DEV__: boolean;
  const __SERVER__: boolean;
}

export {};
